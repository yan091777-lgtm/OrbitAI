const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {Workspace,candidates,buildRequest,parseResponse,day}=require('../core.cjs');
const {models,providers}=require('../catalog.cjs');
const {startServer}=require('../server.cjs');
function fixture(provider='google',group='one',cost='free'){
 return {id:Math.random().toString(),name:'测试账号',provider,type:'api',enabled:true,hasKey:true,models:models.filter(m=>m.provider===provider).map(m=>m.id),cost,freeConfirmed:cost==='free',quotaGroup:group,dailyCap:10,usage:{day:day(),requests:0,tokens:0},status:'ready'};
}
function add(w,provider='google',group='one',cost='free'){
 return w.addAccount({...fixture(provider,group,cost),key:'unit-test-not-a-real-secret'});
}
const query={messages:[{role:'user',content:'你好'}],model:'auto',freeOnly:true,strategy:'balanced'};
test('catalog contains exactly 15 unique models from 8 providers',()=>{assert.equal(models.length,15);assert.equal(new Set(models.map(m=>m.id)).size,15);assert.equal(new Set(models.map(m=>m.provider)).size,8);});
test('free filter rejects unknown and paid, web accounts and disabled keys',()=>{
 const list=[fixture('google'),fixture('openai','paid','paid'),fixture('deepseek','unknown','unknown'),{...fixture('qwen'),type:'web'},{...fixture('zhipu'),enabled:false}];
 const result=candidates('你好','auto','balanced',true,list);assert.ok(result.length);assert.ok(result.every(r=>r.account.provider==='google'));
});
test('manual model selection never silently changes model',()=>{const list=[fixture('google'),fixture('deepseek')];assert.ok(candidates('代码','deepseek-flash','balanced',true,list).every(r=>r.model.id==='deepseek-flash'));assert.equal(candidates('代码','gpt-6-astra','balanced',true,list).length,0);});
test('shared quota group combines requests, including disabled accounts',()=>{const one=fixture(),two=fixture();one.usage.requests=6;two.usage.requests=4;two.enabled=false;assert.equal(candidates('你好','auto','balanced',true,[one,two]).length,0);});
test('daily local cap resets for a previous date and cooldown excludes group',()=>{const a=fixture();a.usage={day:'2020-01-01',requests:500,tokens:0};assert.ok(candidates('你好','auto','balanced',true,[a]).length);a.cooldownUntil=Date.now()+60000;assert.equal(candidates('你好','auto','balanced',true,[a]).length,0);});
test('real request cannot proceed with no eligible credentials',async()=>{let calls=0;const w=new Workspace({transport:async()=>{calls++;}});await assert.rejects(()=>w.chat(query),/没有符合条件/);assert.equal(calls,0);});
test('429 cools all shared keys, fallback goes to another provider',async()=>{
 const calls=[];const w=new Workspace({transport:async url=>{calls.push(url);return url.includes('googleapis')?new Response('{}',{status:429,headers:{'retry-after':'120'}}):new Response(JSON.stringify({choices:[{message:{content:'mock answer'}}],usage:{total_tokens:5}}));}});
 add(w,'google','shared');add(w,'google','shared');add(w,'deepseek','other');
 const result=await w.chat(query);assert.equal(result.model,'deepseek-flash');assert.equal(calls.length,2);assert.equal(result.attempts.length,1);assert.ok(w.state.accounts.filter(a=>a.provider==='google').every(a=>a.cooldownUntil>Date.now()));assert.equal(w.state.accounts.find(a=>a.provider==='deepseek').usage.tokens,5);
});
test('401 invalidates credentials and manual mode does not cross models',async()=>{let calls=0;const w=new Workspace({transport:async()=>{calls++;return new Response('{}',{status:401});}});add(w,'google');add(w,'deepseek');await assert.rejects(()=>w.chat({...query,model:'gemini-3.8-flash'}),/认证或权限失败/);assert.equal(calls,1);assert.equal(w.state.accounts[0].status,'invalid');});
test('paid accounts require explicitly turning off free-only',async()=>{const w=new Workspace();add(w,'openai','one','paid');await assert.rejects(()=>w.chat(query),/没有符合条件/);assert.ok(w.route({...query,text:'test',freeOnly:false}).candidates.length);});
test('cancelled request does not trigger provider failover',async()=>{let calls=0;const w=new Workspace({transport:async(_url,options)=>{calls++;return new Promise((_resolve,reject)=>options.signal.addEventListener('abort',()=>reject(new Error('aborted')),{once:true}));}});add(w,'google');add(w,'deepseek');const controller=new AbortController();const pending=w.chat(query,controller.signal);controller.abort();await assert.rejects(()=>pending,/已停止/);assert.equal(calls,1);assert.equal(w.busy,false);});
test('keys are omitted from public snapshots and never written unencrypted',()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'orbit-test-'));try{const w=new Workspace({dataDir:dir});add(w);assert.ok(!JSON.stringify(w.snapshot()).includes('unit-test-not-a-real-secret'));assert.ok(!fs.readFileSync(path.join(dir,'accounts.json'),'utf8').includes('unit-test-not-a-real-secret'));assert.equal(new Workspace({dataDir:dir}).snapshot().accounts[0].hasKey,false);}finally{fs.rmSync(dir,{recursive:true});}});
test('all four protocol adapters preserve conversational context',()=>{const messages=[{role:'user',content:'hello'},{role:'assistant',content:'hi'},{role:'user',content:'continue'}];for(const p of providers){const req=buildRequest(p,models.find(m=>m.provider===p.id).id,messages,'fake');assert.ok(req.url.startsWith('https://'));assert.ok(!req.url.includes('fake'));if(p.protocol==='gemini')assert.equal(req.body.contents[1].role,'model');else assert.equal((req.body.input||req.body.messages).length,3);}assert.equal(parseResponse('responses',{output:[{content:[{type:'output_text',text:'ok'}]}]}).text,'ok');assert.equal(parseResponse('anthropic',{content:[{type:'thinking',thinking:'private'},{type:'text',text:'ok'}]}).text,'ok');assert.equal(parseResponse('gemini',{candidates:[{content:{parts:[{thought:true,text:'private'},{text:'ok'}]}}]}).text,'ok');});
test('HTTP API requires session cookie and rejects foreign origins',async()=>{const {server,origin}=await startServer(new Workspace());try{assert.equal((await fetch(origin+'/api/state')).status,403);const first=await fetch(origin);const cookie=first.headers.get('set-cookie').split(';')[0];assert.equal((await fetch(origin+'/api/state',{headers:{cookie}})).status,200);assert.equal((await fetch(origin+'/api/accounts',{method:'POST',headers:{cookie,Origin:'https://malicious.example','Content-Type':'application/json'},body:'{}'})).status,403);assert.equal((await fetch(origin+'/core.cjs',{headers:{cookie}})).status,404);}finally{await new Promise(resolve=>server.close(resolve));}});
