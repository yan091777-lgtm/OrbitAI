const providers = [
  {id:'openai',name:'OpenAI',letter:'O',color:'#202020',url:'https://chatgpt.com/',base:'https://api.openai.com/v1',protocol:'responses',docs:'https://developers.openai.com/api/docs/models/all'},
  {id:'anthropic',name:'Anthropic',letter:'✳',color:'#bd765b',url:'https://claude.ai/',base:'https://api.anthropic.com/v1',protocol:'anthropic',docs:'https://platform.claude.com/docs/en/models/overview'},
  {id:'google',name:'Google',letter:'✦',color:'#4285f4',url:'https://gemini.google.com/',base:'https://generativelanguage.googleapis.com/v1beta',protocol:'gemini',docs:'https://ai.google.dev/gemini-api/docs/models'},
  {id:'deepseek',name:'DeepSeek',letter:'D',color:'#536dfe',url:'https://chat.deepseek.com/',base:'https://api.deepseek.com',protocol:'chat',docs:'https://api-docs.deepseek.com/quick_start/pricing/'},
  {id:'qwen',name:'通义千问',letter:'Q',color:'#7257d7',url:'https://www.qianwen.com/',base:'https://dashscope.aliyuncs.com/compatible-mode/v1',protocol:'chat',docs:'https://help.aliyun.com/zh/model-studio/model-list-text-generation/'},
  {id:'moonshot',name:'Kimi',letter:'K',color:'#202020',url:'https://www.kimi.com/',base:'https://api.moonshot.cn/v1',protocol:'chat',docs:'https://help.aliyun.com/zh/model-studio/model-list-text-generation/'},
  {id:'zhipu',name:'智谱 GLM',letter:'Z',color:'#346fe8',url:'https://chatglm.cn/',base:'https://open.bigmodel.cn/api/paas/v4',protocol:'chat',docs:'https://docs.bigmodel.cn/cn/guide/models/text/glm-5.2'},
  {id:'doubao',name:'豆包',letter:'豆',color:'#2b8eaa',url:'https://www.doubao.com/chat/',base:'https://ark.cn-beijing.volces.com/api/v3',protocol:'chat',docs:'https://docs.volcengine.com/docs/ark/coding-plan-personal-model-release?lang=zh'}
];
// Editorial task-fit scores for routing, not published benchmark scores.
const rows = [
 ['gpt-6-astra','GPT-6 Astra','openai','深度推理','复杂研究与多步骤问题',98,65,95,97,90],
 ['gpt-6.1-sol','GPT-6.1 Sol','openai','综合旗舰','编程、分析与日常工作',96,82,98,91,90],
 ['gpt-6-luna','GPT-6 Luna','openai','快速轻量','短问答、提取与日常任务',83,98,80,77,83],
 ['claude-fable-5-1','Claude Fable 5.1','anthropic','深度推理','复杂推理与长程任务',98,60,97,98,95],
 ['claude-opus-5-5','Claude Opus 5.5','anthropic','编程旗舰','复杂代码与知识工作',97,73,99,95,98],
 ['claude-sonnet-5-5','Claude Sonnet 5.5','anthropic','均衡主力','写作、编程与高频工作',94,90,94,87,97],
 ['gemini-3.1-pro-preview','Gemini 3.1 Pro','google','深度分析','复杂分析与长文档理解',95,73,91,97,90],
 ['gemini-3.8-flash','Gemini 3.8 Flash','google','快速主力','快速分析与日常任务',92,97,90,87,88],
 ['deepseek-v4-pro','DeepSeek V4 Pro','deepseek','推理主力','数学、逻辑与代码分析',93,78,92,96,87],
 ['deepseek-flash','DeepSeek V4.1 Flash','deepseek','高效通用','中文问答与快速编程',90,96,90,87,90],
 ['qwen3.8-max','Qwen3.8 Max','qwen','中文旗舰','中文创作与复杂任务',94,80,91,91,97],
 ['qwen3.7-plus','Qwen3.7 Plus','qwen','中文均衡','中文办公与长文整理',90,91,87,86,94],
 ['kimi-k3','Kimi K3','moonshot','长文分析','长文档、研究与代码',94,79,93,95,93],
 ['glm-5.2','GLM-5.2','zhipu','编程推理','代码开发与逻辑推理',91,82,95,92,88],
 ['doubao-seed-2.1-pro','豆包 Seed 2.1 Pro','doubao','中文通用','日常创作与综合任务',90,89,88,87,94]
];
const models = rows.map(([id,name,provider,tag,description,quality,speed,code,reason,write])=>({id,name,provider,tag,description,scores:{quality,speed,code,reason,write},checkedAt:'2026-10-08',preview:id.includes('preview')}));
module.exports = {providers,models};
