const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const {Workspace}=require('./core.cjs');
async function startServer(workspace,port=0){
 const token=crypto.randomBytes(32).toString('hex');
 let origin;
 const server=http.createServer(async(req,res)=>{
  const send=(status,data)=>{if(!res.destroyed){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}};
  if(req.headers.host!==new URL(origin).host)return send(403,{error:'Host rejected'});
  if(req.headers.origin&&req.headers.origin!==origin)return send(403,{error:'Origin rejected'});
  const route=new URL(req.url,origin).pathname;
  if(route.startsWith('/api/')){
   if(!String(req.headers.cookie||'').split(';').some(c=>c.trim()==='orbit_session='+token))return send(403,{error:'请刷新工作台。'});
   const controller=new AbortController();res.on('close',()=>{if(!res.writableEnded)controller.abort();});
   try{
    let data={};if(req.method!=='GET'){if(req.headers['content-type']!=='application/json')return send(415,{error:'Expected JSON'});let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>800000)return send(413,{error:'消息过长。'});}data=JSON.parse(raw||'{}');}
    if(route==='/api/state'&&req.method==='GET')return send(200,workspace.snapshot());
    if(route==='/api/accounts'&&req.method==='POST')return send(200,workspace.addAccount(data));
    if(route==='/api/route'&&req.method==='POST')return send(200,workspace.route(data));
    if(route==='/api/chat'&&req.method==='POST')return send(200,await workspace.chat(data,controller.signal));
    const match=route.match(/^\/api\/accounts\/([a-z0-9-]+)(\/probe)?$/);
    if(match){if(match[2]&&req.method==='POST')return send(200,await workspace.probe(match[1]));if(req.method==='DELETE')return send(200,workspace.removeAccount(match[1]));if(req.method==='PATCH')return send(200,workspace.updateAccount(match[1],data));}
    return send(404,{error:'接口不存在。'});
   }catch(error){return send(error.status||500,{error:error.status?error.message:'请求未完成，请重试。'});}
  }
  const files={'/':'index.html','/app.js':'app.js','/styles.css':'styles.css','/favicon.svg':'favicon.svg'};
  const file=files[route];if(!file||req.method!=='GET')return send(404,{error:'Not found'});
  const type=file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.svg')?'image/svg+xml':'text/html';
  res.writeHead(200,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src 'none'; base-uri 'none'; form-action 'self'",...(file==='index.html'?{'Set-Cookie':`orbit_session=${token}; HttpOnly; SameSite=Strict; Path=/`}:{})});
  fs.createReadStream(path.join(__dirname,'ui',file)).pipe(res);
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});origin=`http://127.0.0.1:${server.address().port}`;
 return {server,origin};
}
module.exports={startServer};
if(require.main===module){const dataDir=process.env.ORBIT_DATA_DIR||path.join(__dirname,'.local-preview');startServer(new Workspace({dataDir}),Number(process.env.PORT)||4317).then(({origin})=>console.log('Orbit AI preview: '+origin)).catch(e=>{console.error(e.message);process.exit(1);});}
