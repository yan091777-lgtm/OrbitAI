const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {providers,models} = require('./catalog.cjs');
const day = () => new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Shanghai'});
const providerOf = id => providers.find(p=>p.id===id);
class AppError extends Error { constructor(message,status=400){super(message);this.status=status;} }
function intentOf(text){
  if(/代码|编程|程序|函数|debug|bug|python|javascript|typescript|react|sql|开发|重构/i.test(text))return 'code';
  if(/证明|推理|数学|研究|分析|对比|逻辑|计算|论文/i.test(text))return 'reason';
  if(/写作|文案|文章|邮件|润色|故事|总结|翻译|中文/i.test(text))return 'write';
  return 'quality';
}
const intentNames={code:'编程开发',reason:'分析推理',write:'写作表达',quality:'通用任务'};
function candidates(text,selection,strategy,freeOnly,accounts){
 const intent=intentOf(text), date=day(), now=Date.now();
 const result=[];
 for(const model of models){
  if(selection!=='auto'&&selection!==model.id)continue;
  for(const account of accounts){
   if(account.type!=='api'||account.provider!==model.provider||!account.enabled||!account.hasKey)continue;
   if(!account.models.includes(model.id)||account.status==='invalid'||account.status==='exhausted')continue;
   if(freeOnly&&!(account.cost==='free'&&account.freeConfirmed))continue;
   if((account.cooldownUntil||0)>now||(account.failedModels?.[model.id]||0)>now)continue;
   const group=accounts.filter(a=>a.type==='api'&&a.provider===account.provider&&a.quotaGroup===account.quotaGroup);
   const used=group.reduce((n,a)=>n+(a.usage?.day===date?a.usage.requests:0),0);
   const cap=Math.min(...group.map(a=>a.dailyCap||100));
   if(used>=cap)continue;
   const task=model.scores[intent];
   const score=strategy==='speed'?model.scores.speed*.75+task*.25:strategy==='quality'?model.scores.quality*.6+task*.4:task*.65+model.scores.speed*.2+model.scores.quality*.15;
   result.push({model,account,score:score+(account.cost==='free'?3:0),intent,reason:`${intentNames[intent]} · ${strategy==='speed'?'速度优先':strategy==='quality'?'质量优先':'均衡选择'} · ${account.cost==='free'?'已确认免费配额':'已允许付费或未知额度'}`});
  }
 }
 return result.sort((a,b)=>b.score-a.score||(a.account.usage?.requests||0)-(b.account.usage?.requests||0));
}
function demoAccounts(){
 return ['google','anthropic','deepseek','qwen','openai','moonshot','zhipu','doubao'].map((id,i)=>({
  id:`demo-${id}`,name:`${providerOf(id).name} · 示例账号`,provider:id,type:'api',enabled:true,hasKey:true,models:models.filter(m=>m.provider===id).map(m=>m.id),
  cost:i===1||i===4?'paid':'free',freeConfirmed:true,quotaGroup:`demo-${id}`,dailyCap:100,status:i===2?'cooldown':'ready',cooldownUntil:i===2?Date.now()+120000:0,
  usage:{day:day(),requests:[12,8,31,5,3,2,0,0][i],tokens:0},demo:true
 }));
}
function buildRequest(provider,modelId,messages,key){
 const headers={'Content-Type':'application/json'};
 let url,body;
 if(provider.protocol==='responses'){
  url=provider.base+'/responses';headers.Authorization=`Bearer ${key}`;
  body={model:modelId,input:messages,max_output_tokens:4096,store:false};
 }else if(provider.protocol==='anthropic'){
  url=provider.base+'/messages';headers['x-api-key']=key;headers['anthropic-version']='2023-06-01';
  body={model:modelId,messages,max_tokens:4096};
 }else if(provider.protocol==='gemini'){
  url=provider.base+'/models/'+encodeURIComponent(modelId)+':generateContent';headers['x-goog-api-key']=key;
  body={contents:messages.map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.content}]})),generationConfig:{maxOutputTokens:4096}};
 }else{
  url=provider.base+'/chat/completions';headers.Authorization=`Bearer ${key}`;
  body={model:modelId,messages,max_tokens:4096,stream:false};
 }
 return {url,headers,body};
}
function parseResponse(protocol,data){
 if(protocol==='responses')return {text:data.output?.flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n')||data.output_text||'',tokens:data.usage?.total_tokens||0};
 if(protocol==='anthropic')return {text:data.content?.filter(c=>c.type==='text').map(c=>c.text).join('\n')||'',tokens:(data.usage?.input_tokens||0)+(data.usage?.output_tokens||0)};
 if(protocol==='gemini')return {text:data.candidates?.[0]?.content?.parts?.filter(p=>!p.thought).map(p=>p.text||'').join('')||'',tokens:data.usageMetadata?.totalTokenCount||0};
 const content=data.choices?.[0]?.message?.content;
 return {text:typeof content==='string'?content:Array.isArray(content)?content.map(c=>c.text||'').join(''):'',tokens:data.usage?.total_tokens||0};
}
class Workspace {
 constructor({dataDir,vault=null,transport=fetch,openWeb=null}={}){
  this.dataDir=dataDir;this.vault=vault;this.transport=transport;this.openWeb=openWeb;this.keys=new Map();this.demo=demoAccounts();this.busy=false;
  this.state={accounts:[],logs:[]};
  if(dataDir){fs.mkdirSync(dataDir,{recursive:true});const file=path.join(dataDir,'accounts.json');if(fs.existsSync(file)){try{this.state=JSON.parse(fs.readFileSync(file,'utf8'));}catch{throw new AppError('账号文件无法读取，请保留文件并检查备份。',500);}}}
 }
 persist(){if(this.dataDir){const file=path.join(this.dataDir,'accounts.json');fs.writeFileSync(file+'.tmp',JSON.stringify(this.state,null,2));fs.renameSync(file+'.tmp',file);}}
 key(a){if(this.keys.has(a.id))return this.keys.get(a.id);if(a.secret&&this.vault){try{return this.vault.decrypt(a.secret);}catch{return null;}}return null;}
 publicAccount(a){const {secret,...rest}=a;return {...rest,hasKey:!!this.key(a),keyHint:this.key(a)?'••••'+this.key(a).slice(-4):'',usage:a.usage?.day===day()?a.usage:{day:day(),requests:0,tokens:0}};}
 snapshot(){return {providers,models,accounts:this.state.accounts.map(a=>this.publicAccount(a)),demoAccounts:this.demo,logs:this.state.logs,desktop:!!this.openWeb,secureStorage:!!this.vault,catalogDate:'2026-10-08'};}
 addAccount(data){
  const provider=providerOf(data.provider);if(!provider)throw new AppError('请选择一个平台。');
  const type=data.type==='web'?'web':'api',name=String(data.name||'').trim().slice(0,60);
  if(!name)throw new AppError('请填写账号名称。');
  const key=String(data.key||'').trim();if(type==='api'&&(!key||key.length>4096))throw new AppError('请填写有效的 API Key。');
  const chosen=Array.isArray(data.models)?data.models.filter(id=>models.some(m=>m.id===id&&m.provider===provider.id)):[];
  if(type==='api'&&!chosen.length)throw new AppError('至少选择一个模型。');
  const dailyCap=Number(data.dailyCap);if(!Number.isInteger(dailyCap)||dailyCap<1||dailyCap>100000)throw new AppError('每日本地请求上限应为 1～100000。');
  const account={id:crypto.randomUUID(),name,provider:provider.id,type,models:chosen,enabled:true,status:type==='web'?'web':'configured',cost:['free','paid'].includes(data.cost)?data.cost:'unknown',freeConfirmed:!!data.freeConfirmed,quotaGroup:String(data.quotaGroup||provider.id).trim().slice(0,100)||provider.id,dailyCap,usage:{day:day(),requests:0,tokens:0},createdAt:Date.now(),failedModels:{}};
  if(account.cost==='free'&&!account.freeConfirmed)throw new AppError('请先确认该账号的免费额度和超额计费设置。');
  if(type==='api'){this.keys.set(account.id,key);if(this.vault)account.secret=this.vault.encrypt(key);}
  this.state.accounts.push(account);this.persist();return this.publicAccount(account);
 }
 updateAccount(id,data){const a=this.state.accounts.find(a=>a.id===id);if(!a)throw new AppError('账号不存在。',404);if(typeof data.enabled==='boolean')a.enabled=data.enabled;this.persist();return this.publicAccount(a);}
 removeAccount(id){if(this.busy)throw new AppError('请等当前回复结束后再移除账号。',409);this.state.accounts=this.state.accounts.filter(a=>a.id!==id);this.keys.delete(id);this.persist();return {ok:true};}
 async probe(id){
  const a=this.state.accounts.find(a=>a.id===id);if(!a)throw new AppError('账号不存在。',404);
  if(a.type==='web'){if(!this.openWeb)throw new AppError('请在桌面版打开独立账号窗口。');await this.openWeb(a);return {message:'已打开独立会话窗口，请在官网完成登录。'};}
  const key=this.key(a);if(!key)throw new AppError('密钥未保存，请重新添加此账号。');
  const p=providerOf(a.provider),headers=p.protocol==='anthropic'?{'x-api-key':key,'anthropic-version':'2023-06-01'}:p.protocol==='gemini'?{'x-goog-api-key':key}:{Authorization:`Bearer ${key}`};
  let res;try{res=await this.transport(p.base+'/models',{headers,signal:AbortSignal.timeout(15000),redirect:'error'});}catch{throw new AppError('连接失败，请检查网络后重试。',502);}
  if(!res.ok){if(res.status===401||res.status===403)a.status='invalid';this.persist();throw new AppError(`平台验证失败（${res.status}）。请检查密钥、权限和地区。`,400);}
  const data=await res.json();const ids=(data.data||data.models||[]).map(m=>(m.id||m.name||'').replace(/^models\//,''));
  const found=a.models.filter(m=>ids.includes(m));a.status='ready';a.verifiedAt=Date.now();this.persist();
  return {message:`密钥验证成功。模型目录匹配 ${found.length}/${a.models.length}；实际调用权限与额度仍以平台为准。`,found};
 }
 route(data){const accounts=data.demo?this.demo:this.state.accounts.map(a=>this.publicAccount(a));const list=candidates(String(data.text||''),data.model||'auto',data.strategy||'balanced',data.freeOnly!==false,accounts);return {intent:intentNames[intentOf(data.text||'')],candidates:list.slice(0,5).map(c=>({model:c.model,account:{id:c.account.id,name:c.account.name},reason:c.reason})),blocked:!list.length};}
 log(event){this.state.logs.unshift({id:crypto.randomUUID(),at:Date.now(),...event});this.state.logs=this.state.logs.slice(0,100);this.persist();}
 async chat(data,signal){
  if(this.busy)throw new AppError('当前还有一个请求在生成，请先等待或停止。',409);
  const messages=Array.isArray(data.messages)?data.messages.filter(m=>['user','assistant'].includes(m.role)&&typeof m.content==='string').map(m=>({role:m.role,content:m.content})):[];
  if(!messages.length||messages.at(-1).role!=='user')throw new AppError('请输入消息。');
  if(messages.reduce((n,m)=>n+m.content.length,0)>120000)throw new AppError('当前会话过长，请新建会话。');
  const text=messages.at(-1).content, isDemo=!!data.demo;
  let list=candidates(text,data.model||'auto',data.strategy||'balanced',data.freeOnly!==false,isDemo?this.demo:this.state.accounts.map(a=>this.publicAccount(a)));
  if(!list.length)throw new AppError('没有符合条件的账号。请添加 API 账号、检查本地上限，或调整“仅使用已确认免费配额”。',409);
  this.busy=true;
  try{
   if(isDemo){
    const chosen=list[0];await new Promise((resolve,reject)=>{const t=setTimeout(resolve,650);signal?.addEventListener('abort',()=>{clearTimeout(t);reject(new AppError('已停止生成。',499));},{once:true});});
    if(signal?.aborted)throw new AppError('已停止生成。',499);
    const sample={code:'我会先明确输入与输出，再拆分实现步骤：\n\n1. 梳理主要功能和边界条件。\n2. 完成一个可以运行的最小版本。\n3. 检查异常情况，再补充必要验证。',reason:'可以按下面的顺序展开：\n\n1. 确认问题、约束和判断标准。\n2. 收集证据，对比不同方案。\n3. 标记不确定性，给出可验证的结论。',write:'可以先确定读者和表达目的，再组织内容：\n\n1. 开头直接说明核心观点。\n2. 用具体例子展开，两到三个重点即可。\n3. 删除重复信息，保持语气一致。',quality:'你的消息已进入自动路由流程。工作台会综合任务类型、所选策略、账号状态和本地请求上限，选择一个符合条件的模型。'}[chosen.intent];
    chosen.account.usage.requests++;return {text:`【本地交互演示 · 未调用 AI】\n\n${sample}\n\n当前选择：${chosen.model.name}\n选择依据：${chosen.reason}\n\n接入真实 API 账号并关闭演示模式后，这里会显示模型的实际回答。`,model:chosen.model.id,modelName:chosen.model.name,accountName:chosen.account.name,reason:chosen.reason,demo:true,tokens:0,attempts:[]};
   }
   const attempts=[],attemptedGroups=new Set();
   for(const choice of list){
    const a=this.state.accounts.find(a=>a.id===choice.account.id);if(!a||!a.enabled)continue;
    const group=a.provider+':'+a.quotaGroup;if(attemptedGroups.has(group))continue;
    if(attempts.length>=3)break;attemptedGroups.add(group);
    if(signal?.aborted)throw new AppError('已停止生成。',499);
    if(a.usage.day!==day())a.usage={day:day(),requests:0,tokens:0};a.usage.requests++;this.persist();
    const p=providerOf(a.provider),request=buildRequest(p,choice.model.id,messages,this.key(a));
    let response;
    try{response=await this.transport(request.url,{method:'POST',headers:request.headers,body:JSON.stringify(request.body),signal:signal?AbortSignal.any([signal,AbortSignal.timeout(90000)]):AbortSignal.timeout(90000),redirect:'error'});}
    catch(error){if(signal?.aborted)throw new AppError('已停止生成。',499);attempts.push({model:choice.model.name,status:'网络错误或超时'});this.log({model:choice.model.name,account:a.name,status:'网络错误或超时'});continue;}
    if(!response.ok){
     const status=response.status;let label=`平台返回 ${status}`;
     if(status===429){const raw=response.headers.get('retry-after');let seconds=Number(raw);if(!Number.isFinite(seconds)&&raw)seconds=(Date.parse(raw)-Date.now())/1000;seconds=Number.isFinite(seconds)&&seconds>0?Math.min(seconds,86400):60;for(const other of this.state.accounts.filter(o=>o.provider===a.provider&&o.quotaGroup===a.quotaGroup)){other.cooldownUntil=Date.now()+seconds*1000;other.status='cooldown';}label='触发限流，额度组冷却中';}
     else if(status===401||status===403){a.status='invalid';label='认证或权限失败';}
     else if(status===402){for(const other of this.state.accounts.filter(o=>o.provider===a.provider&&o.quotaGroup===a.quotaGroup))other.status='exhausted';label='余额或额度不足';}
     else {a.failedModels={...a.failedModels,[choice.model.id]:Date.now()+60000};}
     attempts.push({model:choice.model.name,status:label});this.log({model:choice.model.name,account:a.name,status:label});continue;
    }
    let parsed;try{parsed=parseResponse(p.protocol,await response.json());}catch{parsed={text:'',tokens:0};}
    if(!parsed.text){attempts.push({model:choice.model.name,status:'未返回文本'});this.log({model:choice.model.name,account:a.name,status:'未返回文本'});continue;}
    a.status='ready';a.cooldownUntil=0;a.usage.tokens+=parsed.tokens;this.log({model:choice.model.name,account:a.name,status:'成功',tokens:parsed.tokens});
    return {...parsed,model:choice.model.id,modelName:choice.model.name,accountName:a.name,reason:choice.reason,demo:false,attempts};
   }
   throw new AppError('本次调用未成功：'+attempts.map(a=>a.model+'（'+a.status+'）').join('；')+'。请检查账号池。',502);
  }finally{this.busy=false;}
 }
}
module.exports={Workspace,AppError,candidates,intentOf,buildRequest,parseResponse,day};
