const {app,BrowserWindow,safeStorage,shell,dialog}=require('electron');
const path=require('node:path');
const {Workspace}=require('./core.cjs');
const {providers}=require('./catalog.cjs');
const {startServer}=require('./server.cjs');
let main,server;
const webWindows=new Map();
app.setName('Orbit AI');
if(!app.requestSingleInstanceLock()){app.quit();}else{
 app.on('second-instance',()=>{if(main){if(main.isMinimized())main.restore();main.focus();}});
 app.whenReady().then(async()=>{
  const openWeb=async account=>{
   const existing=webWindows.get(account.id);if(existing&&!existing.isDestroyed()){existing.focus();return;}
   const p=providers.find(p=>p.id===account.provider);
   const win=new BrowserWindow({width:1180,height:820,title:`${account.name} · Orbit AI`,autoHideMenuBar:true,webPreferences:{partition:'persist:orbit-'+account.id,nodeIntegration:false,contextIsolation:true,sandbox:true}});
   webWindows.set(account.id,win);win.on('closed',()=>webWindows.delete(account.id));
   win.webContents.session.setPermissionRequestHandler((_w,permission,callback)=>callback(permission==='clipboard-sanitized-write'));
   const allow=url=>{try{return ['https:','http:'].includes(new URL(url).protocol);}catch{return false;}};
   win.webContents.on('will-navigate',(event,url)=>{if(!allow(url))event.preventDefault();});
   win.webContents.setWindowOpenHandler(({url})=>allow(url)?{action:'allow',overrideBrowserWindowOptions:{autoHideMenuBar:true,webPreferences:{partition:'persist:orbit-'+account.id,nodeIntegration:false,contextIsolation:true,sandbox:true}}}:{action:'deny'});
   await win.loadURL(p.url);
  };
  const vault=safeStorage.isEncryptionAvailable()?{encrypt:s=>safeStorage.encryptString(s).toString('base64'),decrypt:s=>safeStorage.decryptString(Buffer.from(s,'base64'))}:null;
  const workspace=new Workspace({dataDir:path.join(app.getPath('userData'),'workspace'),vault,openWeb});
  const result=await startServer(workspace,4318);server=result.server;
  main=new BrowserWindow({width:1480,height:940,minWidth:860,minHeight:640,title:'Orbit AI',backgroundColor:'#faf9f6',autoHideMenuBar:true,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
  main.webContents.setWindowOpenHandler(({url})=>{if(url.startsWith('https://'))shell.openExternal(url);return {action:'deny'};});
  main.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith(result.origin+'/'))e.preventDefault();});
  main.on('closed',()=>app.quit());
  await main.loadURL(result.origin);
 }).catch(error=>{dialog.showErrorBox('Orbit AI 启动失败',error.code==='EADDRINUSE'?'本地端口 4318 已被占用，请关闭已有 Orbit AI 窗口后重试。':error.message);app.quit();});
 app.on('window-all-closed',()=>app.quit());
 app.on('before-quit',()=>server?.close());
}
