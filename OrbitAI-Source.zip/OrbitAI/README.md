# Orbit AI · 个人模型工作台

第一版 Windows 桌面程序。界面参考 Codex 的侧栏、会话区域和底部输入框，右侧可随时查看账号池。

## 直接启动

打开旁边的 `OrbitAI-Windows` 文件夹，双击 `OrbitAI.exe`。整个文件夹需一起保留；不要单独移动 EXE。

首次打开为明确标记的 **演示模式**。示例账号、请求计数和模板回复均不代表真实 AI 调用，也不会消耗你的额度。

## 使用自己的账号

1. 进入“账号池”，点击“添加账号”。
2. **网页登录**：选择平台并命名。桌面版会打开该账号的独立窗口，由你在官方网页完成登录。再次打开同一账号会复用会话。官网是否接受内嵌浏览器及登录是否过期由平台决定。
3. **API 接入**：填写你自己的 API Key，选择可用模型及额度类型，再保存。密钥用 Windows 系统加密保存在本机。可以先点击“验证连接”。目录验证成功不代表每个模型都拥有调用权限。
4. 顶部切换至“真实模式”。选择“自动选择模型”，或手动选择一个模型，开始文本对话。

网页免费额度和 API 额度是不同的接入方式。**自动选模与统一聊天适用于 API 账号；网页账号在各家官网内使用和选择模型。** 本版没有网页聊天自动抓取或官网额度读取功能。

## 自动选择如何工作

- 使用任务关键词、人工设定的用途优先级、均衡/质量/速度偏好和账号状态进行本地规则路由；不是另一个收费模型在后台判断，也不是性能实测排行榜。
- 默认仅使用你标记并确认的免费配额账号。免费额度及超额计费需在供应商控制台核实，工作台不承诺所有模型免费。
- 网络错误、认证失败或限流时，自动模式最多尝试 3 个不同额度组。429 会依据 Retry-After 冷却同组账号，不通过换同组 Key 反复请求。
- 手动选模时不会静默换成其他模型。
- 同一平台项目下的多个 Key 应填写相同“共享额度组”。同组请求合计受组内最低每日上限控制。
- 本地请求计数按北京时间每日重置，包括已发出的失败尝试。**它不是官方剩余额度。** 账号自身在本程序外的用量无法读取。
- 自动切换供应商时，当前会话上下文会发送给最终选中的供应商；每条回答标明实际模型、账号及路由理由。

## 15 个精选模型

目录于 2026-10-08 根据官方资料核实，后续可能变化。模型开通权限、可用地区与收费以账号控制台为准。

| 平台 | 模型 |
| --- | --- |
| OpenAI | GPT-6 Astra、GPT-6.1 Sol、GPT-6 Luna |
| Anthropic | Claude Fable 5.1、Claude Opus 5.5、Claude Sonnet 5.5 |
| Google | Gemini 3.1 Pro（Preview）、Gemini 3.8 Flash |
| DeepSeek | DeepSeek V4 Pro、DeepSeek V4.1 Flash |
| 通义千问 | Qwen3.8 Max、Qwen3.7 Plus |
| Kimi | Kimi K3 |
| 智谱 | GLM-5.2 |
| 豆包 | Seed 2.1 Pro |

来源：[OpenAI](https://developers.openai.com/api/docs/models/all)、[Anthropic](https://platform.claude.com/docs/en/models/overview)、[Google](https://ai.google.dev/gemini-api/docs/models)、[DeepSeek](https://api-docs.deepseek.com/quick_start/pricing/)、[百炼模型目录](https://help.aliyun.com/zh/model-studio/model-list-text-generation/)、[智谱](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.2)、[火山方舟](https://docs.volcengine.com/docs/ark/coding-plan-personal-model-release?lang=zh)。

## 当前能力与边界

已实现：会话保存/切换/导出、15 模型搜索与手动选择、自动路由、演示模式、API 和网页登录账号池、密钥加密、暂停/移除账号、本地上限、同组限流冷却、错误回退、请求取消、路由记录。

当前为文本对话，生成完成后显示整段回复；尚未提供流式逐字显示、附件、语音和图像生成。官网窗口内可以使用官网提供的功能。

各供应商请求格式已实现并使用模拟响应测试，但没有使用真实用户密钥做线上付费调用验证。网页登录依赖各平台对 Electron 的兼容性，本版不保证所有网站均接受登录。豆包等供应商如要求特定部署 ID，需要在源代码 `catalog.cjs` 中根据控制台调整对应 ID。

移除网页账号只移除工作台入口，不主动清除保留在本机的登录会话。要退出账号，请在对应官网窗口中退出登录后再移除。

本机桌面服务仅监听 `127.0.0.1:4318`。浏览器预览为 `127.0.0.1:4317`，预览密钥仅保存在本次服务运行内存里。桌面与预览数据互相独立。

## 开发与验证

源码为定制的 Electron + 原生 JavaScript 实现，运行时无需额外云服务器；没有复制第三方 AI 客户端的产品代码。

```sh
pnpm install
node node_modules/electron/install.js
pnpm start
```

浏览器预览：`node server.cjs`。测试：`node --test tests/core.test.cjs`。Windows 打包：`node scripts/package.cjs`。

默认接口使用各平台官方端点。API Key 不会返回给前端，日志不记录完整提示词或密钥。应用使用本地会话 Cookie、来源检查、输出转义和隔离的网页窗口。

核心测试覆盖 15 模型目录、免费配额过滤、手动选模保持、共享计数、每日重置、限流回退、认证失效、取消请求、密钥不明文落盘、四种协议转换和本地接口访问限制。

技术依赖：[Electron](https://github.com/electron/electron)；发行目录保留 Electron 与 Chromium 的许可文件。
